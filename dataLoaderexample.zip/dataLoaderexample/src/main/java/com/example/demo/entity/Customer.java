package com.example.demo.entity;


public class Customer {

  private int customerId;

  public Customer(int customerId) {
    this.customerId = customerId;
  }

  public int getCustomerId() {
    return customerId;
  }

  public void setCustomerId(int customerId) {
    this.customerId = customerId;
  }
}
